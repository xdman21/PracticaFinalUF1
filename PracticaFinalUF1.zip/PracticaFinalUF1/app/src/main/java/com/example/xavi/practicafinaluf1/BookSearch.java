package com.example.xavi.practicafinaluf1;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

/**
 * Created by xavi on 11/03/2018.
 */

public class BookSearch extends AppCompatActivity {
    private static final String TAG = BookSearch.class.getSimpleName();
    private EditText BookTitle;
    private TextView Author;
    private TextView Title;
    private ListView lv;
    private Context c;
    static String[] array;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.booksactivity);
        BookTitle = (EditText) findViewById(R.id.bookInput);
        Author = (TextView) findViewById(R.id.authorText);
        Title = (TextView) findViewById(R.id.titleText);
        lv = (ListView) findViewById(R.id.llista);
    }

    public void searchBooks(View view){

        c = getApplicationContext();
        String queryString = BookTitle.getText().toString();

        InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.isConnected() && queryString.length()!=0) {
            FetchBook fb = new FetchBook(Title, Author, c);
            fb.execute(queryString);
            Author.setText("");
            Title.setText(R.string.loading);
        }
        else {
            if (queryString.length() == 0) {
                Author.setText("");
                Title.setText("Please enter a search term");
            } else {
                Author.setText("");
                Title.setText("Please check your network connection and try again.");
            }
        }
    }
}
