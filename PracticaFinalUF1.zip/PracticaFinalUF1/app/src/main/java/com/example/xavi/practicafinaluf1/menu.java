package com.example.xavi.practicafinaluf1;

import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by xavi on 09/03/2018.
 */

public class menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pantallarl fr = new pantallarl();
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.add(R.id.pantallalogin, fr).commit();
    }
}
