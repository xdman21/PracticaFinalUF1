package com.example.xavi.practicafinaluf1;

import android.annotation.SuppressLint;
import android.app.ListFragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;

import com.example.xavi.practicafinaluf1.R;

import static com.example.xavi.practicafinaluf1.R.layout.listfragment;

@SuppressLint("ValidFragment")
public class ListFragmentc extends Fragment implements AdapterView.OnItemClickListener {
    static String[] values;
    static int pos;
    static String[] array;
    static ListView llista;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        array = new String[1];
        array[0] = "Encara No has cercat res";
        return inflater.inflate(R.layout.listfragment,container,false);
    }
    @Override
    public void onActivityCreated(Bundle state)
    {
        super.onActivityCreated(state);
        values = array;
        llista = (ListView) getActivity().findViewById(R.id.llista);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1,values);
        llista.setAdapter(adapter);
        llista.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

    }

}
