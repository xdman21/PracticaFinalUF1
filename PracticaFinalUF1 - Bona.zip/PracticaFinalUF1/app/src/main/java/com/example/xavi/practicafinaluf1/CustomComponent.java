package com.example.xavi.practicafinaluf1;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

/**
 * Created by xavi on 08/02/2018.
 */

public class CustomComponent extends View {
    private Context con;
    @RequiresApi(api = Build.VERSION_CODES.M)
    public CustomComponent(Context context, AttributeSet attributes) {
        super(context, attributes);
        this.con = context;
        Drawable bg = context.getDrawable(R.mipmap.ic_launcher);
        this.setBackground(bg);
    }
}
