package com.example.xavi.practicafinaluf1;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by xavi on 21/02/2018.
 */

public class pantallarl extends Fragment implements View.OnClickListener {
    Button login;
    Button register;
    EditText user;
    EditText password;
    public pantallarl()
    {

    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        return inflater.inflate(R.layout.pantallarl, container, false);
    }
    @Override
    public void onActivityCreated(Bundle state)
    {
        super.onActivityCreated(state);
        login = getView().findViewById(R.id.inicia);
        register = getView().findViewById(R.id.buttonr);
        register.setOnClickListener(this);
        login.setOnClickListener(this);
        user = getView().findViewById(R.id.nom_usuari);
        password = getView().findViewById(R.id.contrasenya);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId())
        {
            case R.id.inicia:
                Context c = getActivity().getApplicationContext();
                SharedPreferences datos = PreferenceManager.getDefaultSharedPreferences(c);
                if(user.getText().toString().equals(datos.getString("usuari","")) && password.getText().toString().equals(datos.getString("contrasenya","")))
                {
                    Toast t = Toast.makeText(c, "Has Iniciat Sessió", Toast.LENGTH_LONG);
                    t.show();
                    startActivity(new Intent(getActivity(), BookSearch.class));
                }
                else
                {
                    Toast t = Toast.makeText(c, "Usuari o contrasenya no correcte", Toast.LENGTH_LONG);
                    t.show();
                }
                break;
            case R.id.buttonr:
                pantallar fr = new pantallar();
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.pantallalogin, fr).commit();
                break;
        }
    }
}
