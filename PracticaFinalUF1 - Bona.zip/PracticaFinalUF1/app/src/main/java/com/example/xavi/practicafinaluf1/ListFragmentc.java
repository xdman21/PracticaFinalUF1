package com.example.xavi.practicafinaluf1;

import android.annotation.SuppressLint;
import android.app.Application;
import android.app.ListActivity;
import android.app.ListFragment;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.ArraySet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.widget.Toast;

import com.example.xavi.practicafinaluf1.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.zip.Inflater;


import static com.example.xavi.practicafinaluf1.R.layout.listfragment;

@SuppressLint("ValidFragment")
public class ListFragmentc extends ListActivity implements AdapterView.OnItemClickListener {
    static String[] values;
    static int pos;
    static String[] array;
    static Context c;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        c = getApplicationContext();
        try
        {
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(c,R.layout.bookslistview,R.id.Itemname,FetchBook.arrayy);
            setListAdapter(adapter);
            ListView listView = getListView();
            listView.setTextFilterEnabled(true);

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    JSONObject json = new JSONObject();
                    JSONObject jsonObject = null;
                    JSONObject itemsArray = null;
                    Log.d("prova","break1");
                    String item = "";
                    try
                    {
                        Log.d("prova","break2"+position);
                        json.put("item",FetchBook.arrayy[position]);
                        Log.d("prova",json.toString());
                        item = json.toString();
                    }
                    catch (JSONException e)
                    {
                        e.printStackTrace();
                    }
                    SharedPreferences data = PreferenceManager.getDefaultSharedPreferences(c);
                    SharedPreferences.Editor editdata = data.edit();
                    item += "-" + data.getString("favtt", "");
                    editdata.putString("favtt", item);
                    Log.d("prova",item);
                    editdata.apply();
                    Toast t = Toast.makeText(getApplication(), "Element Afegit a favorits", Toast.LENGTH_LONG);
                    t.show();
                }
            });
        }
        catch(Exception e)
        {
            array = new String[1];
            array[0] = "Encara No has cercat res";
            values = array;
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.bookslistview, R.id.Itemname, values);
            setListAdapter(adapter);
        }
    }
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
    }
}