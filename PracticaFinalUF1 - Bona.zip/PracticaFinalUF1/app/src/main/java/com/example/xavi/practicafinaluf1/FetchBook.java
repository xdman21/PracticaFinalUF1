package com.example.xavi.practicafinaluf1;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.xavi.practicafinaluf1.NetworkUtils;

import org.json.JSONArray;
import org.json.JSONObject;

public class FetchBook extends AsyncTask<String, Void, String>{
    private TextView mTitleText;
    private TextView mAuthorText;
    Context c;
    static String[] arrayy;
    ArrayAdapter<String> adapter;

    public FetchBook(TextView mTitleText, TextView mAuthorText, Context c){
        this.mTitleText = mTitleText;
        this.mAuthorText = mAuthorText;
        this.c = c;
    }

    @Override
    protected String doInBackground(String... params) {
        return NetworkUtils.getBookInfo(params[0]);
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

        try {
            int lenght = 0;
            JSONObject jsonObject = new JSONObject(s);
            JSONArray itemsArray = jsonObject.getJSONArray("items");

            lenght = itemsArray.length();

            arrayy = new String[lenght];

            for(int i = 0; i<lenght; i++){

                JSONObject book = itemsArray.getJSONObject(i);
                String title=null;
                String authors=null;
                JSONObject volumeInfo = book.getJSONObject("volumeInfo");

                try {
                    if(volumeInfo.getString("title").length() > 35)
                    {
                        title = "No es pot llegir!!!!!";
                        authors = "[]";
                    }
                    else
                    {
                        title = volumeInfo.getString("title");
                        authors = volumeInfo.getString("authors");
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }


                if (title != null && authors != null){
                    arrayy[i] = title + " " + authors;
                }
            }
            mTitleText.setText("S'ha trobat el seguent");
            mAuthorText.setText("");
            c.startActivity(new Intent(c, ListFragmentc.class));

        } catch (Exception e){
            mTitleText.setText("No Results Found");
            mAuthorText.setText("");
            e.printStackTrace();
        }
    }
}
