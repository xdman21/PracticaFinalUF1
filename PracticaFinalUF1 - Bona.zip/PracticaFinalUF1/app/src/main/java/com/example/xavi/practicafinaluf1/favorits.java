package com.example.xavi.practicafinaluf1;

import android.annotation.SuppressLint;
import android.app.ListActivity;
import android.app.ListFragment;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.widget.Toast;

import com.example.xavi.practicafinaluf1.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.ArrayList;
import java.util.Set;

import static com.example.xavi.practicafinaluf1.R.layout.listfragment;

@SuppressLint("ValidFragment")
public class favorits extends ListActivity implements AdapterView.OnItemClickListener {
    static ArrayList<String> favorits;
    int size;
    String[] llistat;
    String valors;
    String[] values;
    @SuppressLint("MissingSuperCall")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        JSONObject jsonObject = null;
        JSONObject itemsfavorits = null;
        values = new String[1];
        Context c = getApplication().getApplicationContext();
        SharedPreferences data = PreferenceManager.getDefaultSharedPreferences(c);
        try {
            favorits = new ArrayList<>();
            Log.d("prova", data.getString("favtt", ""));
            valors = data.getString("favtt", "");
            llistat = valors.split("-");
            size = llistat.length;
            values = new String[size];
            Log.d("prova", "va9");
            JSONObject json = new JSONObject();
            for (int o = 0; o < size; o++)
            {
                json.put("item" + o, llistat[o]);
                favorits.add(json.getString("item" + o));
                values[o] = favorits.get(o);
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(c,R.layout.bookslistview,R.id.Itemname,values);
            setListAdapter(adapter);
            ListView listView = getListView();
            listView.setTextFilterEnabled(true);

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    favorits.remove(position);
                    updateData();
                    Toast t = Toast.makeText(getApplication(), "Element borrat correctament, s'actualitzarà al reiniciar la pàgina", Toast.LENGTH_LONG);
                    t.show();
                }
            });
            Log.d("prova", "va10");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void updateData()
    {
        Context c = getApplication().getApplicationContext();
        SharedPreferences data = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editdata = data.edit();
        String jsonn = "";
        for (int i = 0 ; i < favorits.size() ; i++)
        {
            jsonn += favorits.get(i);
        }
        editdata.putString("favtt", jsonn);
        editdata.apply();
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(c,R.layout.bookslistview,R.id.Itemname,values);
        setListAdapter(adapter);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

    }
}

