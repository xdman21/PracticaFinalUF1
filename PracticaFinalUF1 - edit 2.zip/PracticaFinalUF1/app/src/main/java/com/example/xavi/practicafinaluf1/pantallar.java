package com.example.xavi.practicafinaluf1;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by xavi on 28/02/2018.
 */

@SuppressLint("ValidFragment")
public class pantallar extends Fragment implements View.OnClickListener {
    EditText name;
    EditText password;
    EditText password2;
    Button register;

    public pantallar() {
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.pantallar, container, false);
    }

    @Override
    public void onActivityCreated(Bundle state) {
        super.onActivityCreated(state);
        this.name = getView().findViewById(R.id.rnom_usuari);
        this.password = getView().findViewById(R.id.rcontrasenya1);
        this.password2 = getView().findViewById(R.id.rcontrasenya2);
        this.register = getView().findViewById(R.id.registrarse);
        register.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.registrarse:
                if (password.getText().toString().equals(password2.getText().toString()))
                {
                    saveData();
                }
                else
                {
                    Context c = getActivity().getApplicationContext();
                    Toast t = Toast.makeText(c, "La contrasenya no coincideix", Toast.LENGTH_LONG);
                    t.show();
                }
        }
    }

    public void saveData() {
        Context c = getActivity().getApplicationContext();
        SharedPreferences data = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editdata = data.edit();
        editdata.putString("usuari", name.getText().toString());
        editdata.putString("contrasenya", password.getText().toString());
        editdata.apply();
        pantallarl fr = new pantallarl();
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.replace(R.id.pantallalogin, fr).commit();
}
}