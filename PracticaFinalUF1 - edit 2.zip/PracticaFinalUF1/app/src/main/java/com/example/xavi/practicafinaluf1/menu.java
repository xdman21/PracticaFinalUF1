package com.example.xavi.practicafinaluf1;

import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

/**
 * Created by xavi on 09/03/2018.
 */

public class menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pantallarl fr = new pantallarl();
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.add(R.id.pantallalogin, fr).commit();
    }
    public void onClicked(View view)
    {
        if(isNetworkAvailable() == false)
        {
            Toast t = Toast.makeText(this.getApplicationContext(), "No tens connexió a Internet", Toast.LENGTH_LONG);
            t.show();
        }
        else
        {
            Toast t = Toast.makeText(this.getApplicationContext(), "Tens Connexió a Internet", Toast.LENGTH_LONG);
            t.show();
        }
    }
    private boolean isNetworkAvailable()
    {
        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
}
